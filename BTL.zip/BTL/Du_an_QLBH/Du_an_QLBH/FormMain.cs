﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Du_an_QLBH
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }
        string strcon = @"Data Source=MANHDO\MANHDO;Initial Catalog=QL_LapTop;Integrated Security=True;TrustServerCertificate=True";
        SqlConnection conn = null;

        private void moKetNoi()
        {
            if (conn == null) conn = new SqlConnection(strcon);
            if (conn.State != ConnectionState.Open) conn.Open();
        }
        private void dongKetNoi()
        {
            if (conn != null || conn.State == ConnectionState.Open) conn.Close();
        }

        private Timer timer;
        private void FormMain_Load(object sender, EventArgs e)
        {
            moKetNoi();
            string sql = "select Tendangnhap from DangNhap";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader Data = cmd.ExecuteReader();
            if (Data.Read())
            {
                string tendangnhap = Data[0].ToString();
                //string role = Data[4].ToString();

                if (tendangnhap != null)
                {
                    //Chao xìn
                    tslXinchao.Text += tendangnhap +"!  ";
                }

            }
            

            //Khoi tao gtri ban dau
            toolStripProgressBar1.Minimum = 0;
            toolStripProgressBar1.Maximum = 100;
            toolStripProgressBar1.Value = 0;

            // Khoi tao Timer
            timer = new Timer();
            timer.Interval = 50;
            timer.Tick += Timer_Tick;

            timer.Start();

        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            if (toolStripProgressBar1.Value < toolStripProgressBar1.Maximum){
                // tang gtri ToolStripProgressBar
                toolStripProgressBar1.Value += 5;
            }else{
                timer.Stop();
                Slbl.Text = "Đã sẵn sàng";
            }
        }

        //Goi cac form o Menu Tai khoan
        private void mnuDN_Click(object sender, EventArgs e)
        {
            //chuyen form
            FormDangNhap fLogin = new FormDangNhap();
            fLogin.Show();
            this.Close();
        }
        private void mnuThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Tao form
        private Form currentFormChild;
        //Dua form con vao form cha
        private void moFormChild(Form childForm)
        {
            if (currentFormChild != null)currentFormChild.Close();
            currentFormChild = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelBody.Controls.Add(childForm);
            panelBody.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        //Goi cac form o Menu chuc nang
        private void mnuQLSP_Click(object sender, EventArgs e)
        {
            moFormChild(new QLSP());          
        }
        private void mnuQLDH_Click(object sender, EventArgs e)
        {
            moFormChild(new QLHD());
        }
        private void mnuQLNH_Click(object sender, EventArgs e)
        {
            moFormChild(new QLNH());
        }

        private void tslXinchao_Click(object sender, EventArgs e)
        {

        }
    }
}
