﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Du_an_QLBH
{
    public partial class QLNH : Form
    {
        public QLNH()
        {
            InitializeComponent();
        }
        private void QLNH_Load(object sender, EventArgs e)
        {
          
            HienThiDS();
            LoadCbbNCC("");
            LoadCbbNV("");
            LoadCbbSP("");
            btnSua.Enabled = false;
            btnXoa.Enabled = false;

        }

        //chuoi ket noi
        string strcon = @"Data Source=MANHDO\MANHDO;Initial Catalog=QL_LapTop;Integrated Security=True;TrustServerCertificate=True";
        //doi tuong ket noi
        DataSet ds = null;
        SqlDataAdapter adapter = null;
        SqlConnection sqlcon = null;

        //ham mo ket noi
        private void MoKetNoi()
        {
            if(sqlcon==null) sqlcon = new SqlConnection(strcon);
            if(sqlcon.State == ConnectionState.Closed) sqlcon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlcon != null && sqlcon.State == ConnectionState.Open)
            {
                sqlcon.Close();
            }
        }

        //hien thi danh sach
        private void HienThiDS()
        {
            MoKetNoi();
           //lenh truy van
            string sqlcmd = "select * from NhapHang";
            adapter = new SqlDataAdapter(sqlcmd, sqlcon);
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();
            adapter.Fill(ds,"NhapHang");
            dgvDanhSach.DataSource = ds.Tables["NhapHang"];
            foreach (DataColumn col in ds.Tables["NhapHang"].Columns)
            {
                Console.WriteLine(col.ColumnName);
            }

            DongKetNoi();
        }

        //tìm kiếm
        private void TimKiemTheoPN(String MaPN)
        {
            MoKetNoi();
            //lenh truy van 
            string sqlcmd = @"select * from NhapHang where MaNH = '"+MaPN+"'";
            adapter = new SqlDataAdapter(sqlcmd, sqlcon);
            //SqlCommandBuilder builder = new SqlCommandBuilder( adapter);//lệnh này thực thi thay đổi database
            ds = new DataSet();
            adapter.Fill(ds,"TKMaPN");
            dgvDanhSach.DataSource = ds.Tables["TKMaPN"];
            DongKetNoi();
        }


        private void TimKiemTheoNCC(String MaNCC)
        {
            MoKetNoi();
            //lenh truy van 
            string sqlcmd = @"select * from NhapHang where MaNCC = '" + MaNCC + "' ";
            SqlDataAdapter adapter = new SqlDataAdapter(sqlcmd, sqlcon);
            ds = new DataSet();
            adapter.Fill(ds, "TKMaNCC");
            dgvDanhSach.DataSource = ds.Tables["TKMaNCC"];
            DongKetNoi();
        }

        //Thêm Phiếu Nhập
        private void ThemPN()
        {
            MoKetNoi();

            // Kiểm tra nếu bảng "NhapHang" đã tồn tại
            if (ds == null || !ds.Tables.Contains("NhapHang"))
            {
                string sqlcmd = "SELECT * FROM NhapHang";
                adapter = new SqlDataAdapter(sqlcmd, sqlcon);// co the ket noi va dien vao dataset
                ds = new DataSet();
                adapter.Fill(ds, "NhapHang");
            }

            if (ds.Tables.Contains("NhapHang"))
            {
                DataRow row = ds.Tables["NhapHang"].NewRow();
                row["MaNH"] = txtMaPN.Text.Trim();
                row["NgayNhap"] = dtpNgayNhap.Value.Year + "-" + dtpNgayNhap.Value.Month + "-" + dtpNgayNhap.Value.Day;
                row["MaSP"] = cbMaSP.Text.Trim();
                row["MaNCC"] = cbMaNCC.Text.Trim();
                row["MaNV"] = cbMaNV.Text.Trim();
                row["Gia"] = txtGia.Text.Trim();
                row["SoLuong"] = nudSoLuong.Value.ToString();
                row["TongTien"] = txtThanhTien.Text.Trim();

                ds.Tables["NhapHang"].Rows.Add(row);

                // Cập nhật vào cơ sở dữ liệu
                //SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                int ketqua = adapter.Update(ds, "NhapHang");

                if (ketqua > 0)
                {
                    HienThiDS();
                    MessageBox.Show("Thêm phiếu nhập thành công!");
                    XoaDuLieu();
                }
                else
                {
                    MessageBox.Show("Thêm phiếu nhập không thành công!");
                }
            }
            else
            {
                MessageBox.Show("Không thể thêm phiếu nhập. Bảng NhapHang không tồn tại.");
            }

            DongKetNoi();
        }

        //sửa phiếu nhập
        private void Sua_PhieuNhap()
        {
            if (vt == -1) return;

            MoKetNoi();

            string BangHienTai = "";
            if (dgvDanhSach.DataSource == ds.Tables["NhapHang"])
            {
                BangHienTai = "NhapHang";
            }
            else if (dgvDanhSach.DataSource == ds.Tables["TKMaPN"])
            {
                BangHienTai = "TKMaPN";
            }
            else if (dgvDanhSach.DataSource == ds.Tables["TKMaNCC"])
            {
                BangHienTai = "TKMaNCC";
            }

            DataRow row = ds.Tables[BangHienTai].Rows[vt];
            row.BeginEdit();

            row["MaNH"] = txtMaPN.Text.Trim();
            row["NgayNhap"] = dtpNgayNhap.Value.Year + "-" + dtpNgayNhap.Value.Month + "-" + dtpNgayNhap.Value.Day;
            row["MaSP"] = cbMaSP.Text.Trim();
            row["MaNCC"] = cbMaNCC.Text.Trim();
            row["MaNV"] = cbMaNV.Text.Trim();
            row["Gia"] = txtGia.Text.Trim();
            row["SoLuong"] = nudSoLuong.Value.ToString();
            row["TongTien"] = txtThanhTien.Text.Trim();

            row.EndEdit();

            //ds.Tables["NhapHang"].Rows.update(row);
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);

            int ketqua = adapter.Update(ds, BangHienTai);

            if (ketqua > 0)
            {
                MessageBox.Show("Sửa phiếu nhập thành công!");
                XoaDuLieu();
                HienThiDS();
                LoadCbbNCC("");
                LoadCbbNV("");
                LoadCbbSP("");
            }
            else
            {
                MessageBox.Show("Sửa phiếu nhập không thành công!");
            }

            DongKetNoi();
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
        }

        //xóa phiếu nhập
        private void Xoa_PhieuNhap()
        {
            MoKetNoi();

            DataRow row = ds.Tables["NhapHang"].Rows[vt];
            row.Delete();

            int ketqua = adapter.Update(ds, "NhapHang");

            if (ketqua > 0)
            {
                MessageBox.Show("Xóa phiếu nhập thành công!");
                XoaDuLieu();
                HienThiDS();
                LoadCbbNCC("");
                LoadCbbNV("");
                LoadCbbSP("");
            }
            else
            {
                MessageBox.Show("Xóa phiếu nhập không thành công!");
            }

            DongKetNoi();
            btnSua.Enabled = false;
            btnXoa.Enabled = false;

            DongKetNoi();
        }
        // Đề xuất TT NV
        private void LoadCbbNV(string MaNV)
        {
            MoKetNoi();
            string sqlcmd = string.IsNullOrEmpty(MaNV)
                ? "SELECT MaNV FROM NhanVien"
                : "SELECT MaNV FROM NhanVien WHERE MaNV = '" + MaNV + "'";

            SqlCommand command = new SqlCommand(sqlcmd, sqlcon);//gan vao ket noi

            SqlDataAdapter adapter = new SqlDataAdapter(command); //tao doi tuong adapter nhan du lieu tu sql

            DataSet ds = new DataSet();
            adapter.Fill(ds, "MaNV"); // truyen lieu tu sql vao ds

            cbMaNV.Items.Clear();

            foreach (DataRow row in ds.Tables["MaNV"].Rows)//dataset chia thanh nhieu datatable, 1 dttable co nhieu datarow 
            {
                cbMaNV.Items.Add(row["MaNV"].ToString());
            }
            DongKetNoi();
        }

        private void HienThiTTNV(string MaNV)
        {
            MoKetNoi();
            string sqlcmd = @"select TenNV  from NhanVien where MaNV = '"+MaNV+"'";
            SqlCommand command = new SqlCommand( sqlcmd, sqlcon);
            SqlDataAdapter adapter = new SqlDataAdapter(command);

            DataSet ds = new DataSet();
            adapter.Fill(ds, "ThongTinCT_NhanVien");

            DataRow row = ds.Tables["ThongTinCT_NhanVien"].Rows[0]; // gan vao dong dau tien
            txtTenNV.Text = row["TenNV"].ToString();
            DongKetNoi();
        }
        //selected index
        private void cbMaNV_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedMaNV = cbMaNV.SelectedItem.ToString();
            HienThiTTNV(selectedMaNV);

        }

        //hien thi chi tiet TT San Pham
        private void LoadCbbSP(string MaSP)
        {
            MoKetNoi();
            string sqlcmd = string.IsNullOrEmpty(MaSP)
                ? "SELECT MaSP FROM SanPham"
                : "SELECT MaSP FROM SanPham WHERE MaSP ='" + MaSP + "'";

            SqlCommand command = new SqlCommand(sqlcmd, sqlcon);

            SqlDataAdapter adapter = new SqlDataAdapter(command);

            DataSet ds = new DataSet();
            adapter.Fill(ds, "MaSP");

            cbMaSP.Items.Clear();

            foreach (DataRow row in ds.Tables["MaSP"].Rows)
            {
                cbMaSP.Items.Add(row["MaSP"].ToString());
            }
            DongKetNoi();
        }
        private void HienThiTTSP(string MaSP)
        {
            MoKetNoi();

            string sqlcmd = @"SELECT TenSP FROM SanPham WHERE MaSP = '" + MaSP + "'";

            SqlCommand sqlcommand = new SqlCommand(sqlcmd, sqlcon);
            SqlDataAdapter adapter = new SqlDataAdapter(sqlcommand);

            DataSet dssp = new DataSet();
            
            adapter.Fill(dssp, "TTSP");

            // Lấy giá trị từ DataSet và gán vào các TextBox
            if (dssp.Tables["TTSP"].Rows.Count > 0)
            {
                DataRow row = dssp.Tables["TTSP"].Rows[0];
                txtTenSP.Text = row["TenSP"].ToString(); 
            }
            DongKetNoi();
        }

        private void cbMaSP_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedSP = cbMaSP.SelectedItem.ToString(); ;
            HienThiTTSP(selectedSP);
        }

        //Đề xuất TT NCC
        private void LoadCbbNCC(string MaNCC)
        {
            MoKetNoi();
            string sqlcmd = string.IsNullOrEmpty(MaNCC)
                ? "SELECT MaNCC FROM NCC"
                : "SELECT MaNCC FROM NCC WHERE MaNCC ='"+MaNCC+"'";

                    SqlCommand command = new SqlCommand(sqlcmd, sqlcon);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                
                    DataSet ds = new DataSet();
                    adapter.Fill(ds, "MaNCC");

                    cbMaNCC.Items.Clear();

                    foreach (DataRow row in ds.Tables["MaNCC"].Rows)
                    {
                        cbMaNCC.Items.Add(row["MaNCC"].ToString());
                    }
            DongKetNoi();
        }

        //hien thi chi tiet TT NCC
        private void HienThiTTNCC(string MaNCC)
        {
                MoKetNoi();

                string sqlcmd = @"SELECT TenNCC, DiaChi, SDT FROM NCC WHERE MaNCC = '" + MaNCC + "'";

                SqlCommand sqlcommand = new SqlCommand(sqlcmd, sqlcon);
                SqlDataAdapter adapter = new SqlDataAdapter(sqlcommand);

                DataSet ds = new DataSet();
            
                adapter.Fill(ds, "TTNCC");

            // Lấy giá trị từ DataSet và gán vào các TextBox            
                DataRow row = ds.Tables["TTNCC"].Rows[0];
                txtTenNCC.Text = row["TenNCC"].ToString();
                txtDiaChi.Text = row["DiaChi"].ToString();
                txtSDT.Text = row["SDT"].ToString();
            
                DongKetNoi();

        }

        //chon du lieu tu combobox
        private void cbMaNCC_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedMaNCC = cbMaNCC.SelectedItem.ToString();
            HienThiTTNCC(selectedMaNCC);
        }

        //ham tinh tong tien     
        private void TinhTongTien()
        {
            try 
            {
                decimal soLuong = Convert.ToDecimal(nudSoLuong.Value);
                decimal gia = Convert.ToDecimal(txtGia.Text.Trim());
                if (soLuong > 0 && gia > 0)
                {

                    decimal tongTien = soLuong * gia;
                    txtThanhTien.Text = tongTien.ToString("N0");
                }
            }
            catch 
            {
                
            }   
        }
        private void nudSoLuong_ValueChanged(object sender, EventArgs e)
        {
            string Gia = txtGia.Text;
            if(Gia!= "" || Gia != null)
            {
                TinhTongTien();
            }
            
        }

        private void txtGia_Leave(object sender, EventArgs e)
        {
            int SoLuong = (int)nudSoLuong.Value;
            if (SoLuong > 0)
            {
                TinhTongTien();
            }
        }

        // hàm xóa dl
        private void XoaDuLieu()
        {
            txtMaPN.Clear();
            txtGia.Clear();  
            txtGia.Clear();
            
            txtTenSP.Clear();
            txtTenNV.Clear();
            txtTenNCC.Clear();
            //cbMaNCC.Items.Clear();
            //cbMaNV.Items.Clear();
        }

        //Button area
        private void btnThem_Click(object sender, EventArgs e)
        {
            ThemPN();
        }
        private void btnSua_Click(object sender, EventArgs e)
        {
            Sua_PhieuNhap();
        }
       private void btnXoa_Click(object sender, EventArgs e)
        {
            if (vt == -1) return;
            DialogResult result = MessageBox.Show("Bạn có thực sự muốn xóa không?", "Hộp thoại", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if(result == DialogResult.Yes) { Xoa_PhieuNhap();}            
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có thực sự muốn thoát?",
                "Hộp thoại", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes) Close();
        }

        private void btnTKPN_Click(object sender, EventArgs e)
        {
            //lay du lieu  tu tim kiem
            string MaPN = txtTKMaPN.Text.Trim();
            string MaNCC = txtTKMaNCC.Text.Trim();
            //string NgayNhap = dtpTKNgayNhap.ToString().val;

            if(MaPN != ""&& MaNCC=="")
            {
                TimKiemTheoPN(MaPN);
            }
            else if (MaPN == "" && MaNCC != "")
            {
                TimKiemTheoNCC(MaNCC);
            }
            else if(MaPN != "" && MaNCC != "")
            {
                TimKiemTheoPN(MaPN);
            }
            else if(MaPN =="" &&  MaNCC =="")
            { MessageBox.Show("Bạn chưa nhập thông tin");
              txtTKMaPN.Focus();
            }
        }
        int vt = -1;
        //private void dgvDanhSach_CellClick(object sender, DataGridViewCellEventArgs e)
        //{
        //        vt = e.RowIndex;
        //        if (vt == -1) return;

        //        DataRow row = ds.Tables["NhapHang"].Rows[vt];
        //        txtMaPN.Text = row["MaNH"].ToString().Trim();
        //        //MessageBox.Show(row["NgayNhap"].ToString());
        //        string[] nn = row["NgayNhap"].ToString().Trim().Split('/');
        //        string ngay = nn[1];
        //        string thang = nn[0];
        //        string nam = nn[2].Split(' ')[0];
        //        dtpNgayNhap.Value = new DateTime(int.Parse(nam), int.Parse(ngay), int.Parse(thang));

        //        cbMaSP.Text = row["MaSP"].ToString().Trim();
        //        txtGia.Text = row["Gia"].ToString();
        //        nudSoLuong.Value = Convert.ToDecimal(row["SoLuong"]);

        //        decimal thanhTien = Convert.ToDecimal(row["TongTien"]);
        //        txtThanhTien.Text = thanhTien.ToString("N0");

        //        cbMaNV.Text = row["MaNV"].ToString().Trim();
        //        cbMaNCC.Text = row["MaNCC"].ToString().Trim();

        //        btnSua.Enabled = true;
        //        btnXoa.Enabled = true;                              
        //}

        private void dgvDanhSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            vt = e.RowIndex;
            if (vt == -1) return;

            string BangHienTai = "";
            if (dgvDanhSach.DataSource == ds.Tables["NhapHang"])
            {
                BangHienTai = "NhapHang";
            }
            else if (dgvDanhSach.DataSource == ds.Tables["TKMaPN"])
            {
                BangHienTai = "TKMaPN";
            }
            else if (dgvDanhSach.DataSource == ds.Tables["TKMaNCC"])
            {
                BangHienTai = "TKMaNCC";
            }
            DataRow row = ds.Tables[BangHienTai].Rows[vt];

            txtMaPN.Text = row["MaNH"].ToString().Trim();
            dtpNgayNhap.Value = DateTime.Parse(row["NgayNhap"].ToString());
            cbMaSP.Text = row["MaSP"].ToString().Trim();
            txtGia.Text = row["Gia"].ToString();
            nudSoLuong.Value = Convert.ToDecimal(row["SoLuong"]);
            txtThanhTien.Text = row["TongTien"].ToString();
            cbMaNV.Text = row["MaNV"].ToString().Trim();
            cbMaNCC.Text = row["MaNCC"].ToString().Trim();

            btnSua.Enabled = true;
            btnXoa.Enabled = true;
        }

        private void btnHienThi_Click(object sender, EventArgs e)
        {
            HienThiDS();
        }
    }
}
