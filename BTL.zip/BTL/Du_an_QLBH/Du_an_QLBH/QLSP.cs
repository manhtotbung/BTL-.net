﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Du_an_QLBH
{
    public partial class QLSP : Form
    {
        public QLSP()
        {
            InitializeComponent();
        }

    }
}
