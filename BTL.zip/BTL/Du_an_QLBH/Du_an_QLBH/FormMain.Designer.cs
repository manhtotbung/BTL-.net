﻿namespace Du_an_QLBH
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuTKhoan = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDN = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThoat = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDanhMuc = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuNhanVien = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuKhachHang = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuChucNang = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuQLSP = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuQLDH = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuQLNH = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBaoCao = new System.Windows.Forms.ToolStripMenuItem();
            this.mlistDoanhthu = new System.Windows.Forms.ToolStripMenuItem();
            this.mlistTop5banchay = new System.Windows.Forms.ToolStripMenuItem();
            this.mlistTop5khoban = new System.Windows.Forms.ToolStripMenuItem();
            this.mlistHethang = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.Slbl = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbImg = new System.Windows.Forms.ToolStripButton();
            this.tslXinchao = new System.Windows.Forms.ToolStripLabel();
            this.tslNgaygio = new System.Windows.Forms.ToolStripLabel();
            this.panelBody = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuTKhoan,
            this.mnuDanhMuc,
            this.mnuChucNang,
            this.mnuHelp});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1237, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuTKhoan
            // 
            this.mnuTKhoan.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuDN,
            this.mnuThoat});
            this.mnuTKhoan.Name = "mnuTKhoan";
            this.mnuTKhoan.Size = new System.Drawing.Size(102, 29);
            this.mnuTKhoan.Text = "Tài khoản";
            // 
            // mnuDN
            // 
            this.mnuDN.Image = ((System.Drawing.Image)(resources.GetObject("mnuDN.Image")));
            this.mnuDN.Name = "mnuDN";
            this.mnuDN.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F1)));
            this.mnuDN.Size = new System.Drawing.Size(267, 34);
            this.mnuDN.Text = "Đăng nhập";
            this.mnuDN.Click += new System.EventHandler(this.mnuDN_Click);
            // 
            // mnuThoat
            // 
            this.mnuThoat.Image = ((System.Drawing.Image)(resources.GetObject("mnuThoat.Image")));
            this.mnuThoat.Name = "mnuThoat";
            this.mnuThoat.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.mnuThoat.Size = new System.Drawing.Size(267, 34);
            this.mnuThoat.Text = "Thoát";
            this.mnuThoat.Click += new System.EventHandler(this.mnuThoat_Click);
            // 
            // mnuDanhMuc
            // 
            this.mnuDanhMuc.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuNhanVien,
            this.mnuKhachHang});
            this.mnuDanhMuc.Name = "mnuDanhMuc";
            this.mnuDanhMuc.Size = new System.Drawing.Size(109, 29);
            this.mnuDanhMuc.Text = "Danh mục";
            // 
            // mnuNhanVien
            // 
            this.mnuNhanVien.Name = "mnuNhanVien";
            this.mnuNhanVien.Size = new System.Drawing.Size(206, 34);
            this.mnuNhanVien.Text = "Nhân viên";
            // 
            // mnuKhachHang
            // 
            this.mnuKhachHang.Name = "mnuKhachHang";
            this.mnuKhachHang.Size = new System.Drawing.Size(206, 34);
            this.mnuKhachHang.Text = "Khách hàng";
            // 
            // mnuChucNang
            // 
            this.mnuChucNang.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuQLSP,
            this.mnuQLDH,
            this.mnuQLNH,
            this.mnuBaoCao});
            this.mnuChucNang.Name = "mnuChucNang";
            this.mnuChucNang.Size = new System.Drawing.Size(113, 29);
            this.mnuChucNang.Text = "Chức năng";
            // 
            // mnuQLSP
            // 
            this.mnuQLSP.Image = ((System.Drawing.Image)(resources.GetObject("mnuQLSP.Image")));
            this.mnuQLSP.Name = "mnuQLSP";
            this.mnuQLSP.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.S)));
            this.mnuQLSP.Size = new System.Drawing.Size(377, 34);
            this.mnuQLSP.Text = "Quản lý sản phẩm";
            this.mnuQLSP.Click += new System.EventHandler(this.mnuQLSP_Click);
            // 
            // mnuQLDH
            // 
            this.mnuQLDH.Image = ((System.Drawing.Image)(resources.GetObject("mnuQLDH.Image")));
            this.mnuQLDH.Name = "mnuQLDH";
            this.mnuQLDH.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.D)));
            this.mnuQLDH.Size = new System.Drawing.Size(377, 34);
            this.mnuQLDH.Text = "Quản lý hóa đơn";
            this.mnuQLDH.Click += new System.EventHandler(this.mnuQLDH_Click);
            // 
            // mnuQLNH
            // 
            this.mnuQLNH.Image = ((System.Drawing.Image)(resources.GetObject("mnuQLNH.Image")));
            this.mnuQLNH.Name = "mnuQLNH";
            this.mnuQLNH.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.N)));
            this.mnuQLNH.Size = new System.Drawing.Size(377, 34);
            this.mnuQLNH.Text = "Quản lý nhập hàng";
            this.mnuQLNH.Click += new System.EventHandler(this.mnuQLNH_Click);
            // 
            // mnuBaoCao
            // 
            this.mnuBaoCao.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mlistDoanhthu,
            this.mlistTop5banchay,
            this.mlistTop5khoban,
            this.mlistHethang});
            this.mnuBaoCao.Image = ((System.Drawing.Image)(resources.GetObject("mnuBaoCao.Image")));
            this.mnuBaoCao.Name = "mnuBaoCao";
            this.mnuBaoCao.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.B)));
            this.mnuBaoCao.Size = new System.Drawing.Size(377, 34);
            this.mnuBaoCao.Text = "Báo cáo";
            // 
            // mlistDoanhthu
            // 
            this.mlistDoanhthu.Name = "mlistDoanhthu";
            this.mlistDoanhthu.Size = new System.Drawing.Size(317, 34);
            this.mlistDoanhthu.Text = "Doanh thu";
            // 
            // mlistTop5banchay
            // 
            this.mlistTop5banchay.Name = "mlistTop5banchay";
            this.mlistTop5banchay.Size = new System.Drawing.Size(317, 34);
            this.mlistTop5banchay.Text = "Top 5 sản phẩm bán chạy";
            // 
            // mlistTop5khoban
            // 
            this.mlistTop5khoban.Name = "mlistTop5khoban";
            this.mlistTop5khoban.Size = new System.Drawing.Size(317, 34);
            this.mlistTop5khoban.Text = "Top 5 sản phẩm khó bán";
            // 
            // mlistHethang
            // 
            this.mlistHethang.Name = "mlistHethang";
            this.mlistHethang.Size = new System.Drawing.Size(317, 34);
            this.mlistHethang.Text = "Sản phẩm sắp hết hàng";
            // 
            // mnuHelp
            // 
            this.mnuHelp.Name = "mnuHelp";
            this.mnuHelp.Size = new System.Drawing.Size(93, 29);
            this.mnuHelp.Text = "Trợ giúp";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBar1,
            this.Slbl});
            this.statusStrip1.Location = new System.Drawing.Point(0, 571);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1237, 32);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 24);
            // 
            // Slbl
            // 
            this.Slbl.Name = "Slbl";
            this.Slbl.Size = new System.Drawing.Size(40, 25);
            this.Slbl.Text = "hihi";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbImg,
            this.tslXinchao,
            this.tslNgaygio});
            this.toolStrip1.Location = new System.Drawing.Point(0, 33);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1237, 30);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbImg
            // 
            this.tsbImg.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbImg.Image = ((System.Drawing.Image)(resources.GetObject("tsbImg.Image")));
            this.tsbImg.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbImg.Name = "tsbImg";
            this.tsbImg.Size = new System.Drawing.Size(34, 25);
            this.tsbImg.Text = "toolStripButton1";
            // 
            // tslXinchao
            // 
            this.tslXinchao.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tslXinchao.Name = "tslXinchao";
            this.tslXinchao.Size = new System.Drawing.Size(96, 25);
            this.tslXinchao.Text = "Xin chào, ";
            this.tslXinchao.Click += new System.EventHandler(this.tslXinchao_Click);
            // 
            // tslNgaygio
            // 
            this.tslNgaygio.Name = "tslNgaygio";
            this.tslNgaygio.Size = new System.Drawing.Size(85, 25);
            this.tslNgaygio.Text = "Ngày giờ";
            // 
            // panelBody
            // 
            this.panelBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBody.Location = new System.Drawing.Point(0, 63);
            this.panelBody.Name = "panelBody";
            this.panelBody.Size = new System.Drawing.Size(1237, 508);
            this.panelBody.TabIndex = 5;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1237, 603);
            this.Controls.Add(this.panelBody);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormMain";
            this.Text = "Phần mềm quản lý bán hàng";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuTKhoan;
        private System.Windows.Forms.ToolStripMenuItem mnuDN;
        private System.Windows.Forms.ToolStripMenuItem mnuThoat;
        private System.Windows.Forms.ToolStripMenuItem mnuDanhMuc;
        private System.Windows.Forms.ToolStripMenuItem mnuNhanVien;
        private System.Windows.Forms.ToolStripMenuItem mnuKhachHang;
        private System.Windows.Forms.ToolStripMenuItem mnuChucNang;
        private System.Windows.Forms.ToolStripMenuItem mnuQLSP;
        private System.Windows.Forms.ToolStripMenuItem mnuQLDH;
        private System.Windows.Forms.ToolStripMenuItem mnuQLNH;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuBaoCao;
        private System.Windows.Forms.ToolStripMenuItem mlistDoanhthu;
        private System.Windows.Forms.ToolStripMenuItem mlistTop5banchay;
        private System.Windows.Forms.ToolStripMenuItem mlistTop5khoban;
        private System.Windows.Forms.ToolStripMenuItem mlistHethang;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbImg;
        private System.Windows.Forms.ToolStripLabel tslNgaygio;
        private System.Windows.Forms.Panel panelBody;
        private System.Windows.Forms.ToolStripLabel tslXinchao;
        private System.Windows.Forms.ToolStripStatusLabel Slbl;
    }
}