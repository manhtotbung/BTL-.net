﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Du_an_QLBH
{
    public partial class FormDangNhap : Form
    {
        public FormDangNhap()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblError.Visible = false;

        }
        string strcon = @"Data Source=MANHDO\MANHDO;Initial Catalog=QL_LapTop;Integrated Security=True;TrustServerCertificate=True";
        SqlConnection conn = null;

        private void moKetNoi()
        {
            if (conn == null) conn = new SqlConnection(strcon);
            if(conn.State != ConnectionState.Open) conn.Open();
        }
        private void dongKetNoi()
        {
            if(conn != null || conn.State == ConnectionState.Open)conn.Close();
        }
        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            moKetNoi();
            string sql = "select *from DangNhap where Tendangnhap='"+ txtUser.Text + "' and Matkhau='"+ txtPass.Text + "'";
            
            SqlCommand cmd = new SqlCommand(sql,conn);
            SqlDataReader Data = cmd.ExecuteReader();

            if (Data.Read())
            {
                FormMain fMain = new FormMain();
                fMain.Show();
                this.Hide();
            }else if(!Data.Read()){
                lblError.Visible = true;
                lblError.Text = "Chưa nhập tên đăng nhập hoặc mật khẩu!";
                txtUser.Focus();
            }else{
                lblError.Visible = true;
                lblError.Text = "Sai tên đăng nhập hoặc mật khẩu!";
            }
            dongKetNoi();
        }
    }
}
